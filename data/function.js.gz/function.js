var xmlHttp=createXmlHttpObject();
function createXmlHttpObject(){
 if(window.XMLHttpRequest){
  xmlHttp=new XMLHttpRequest();
 }else{
  xmlHttp=new ActiveXObject('Microsoft.XMLHTTP');
 }
 return xmlHttp;
}
function load(){
 if(xmlHttp.readyState==0 || xmlHttp.readyState==4){
  xmlHttp.open('PUT','/config.xml',true);
  xmlHttp.onreadystatechange=handleServerResponse;
  xmlHttp.send(null);
 }
}
function val(id){
 var v = document.getElementById(id).value;
 return v;
}
function xml(id){
 xmlResponse=xmlHttp.responseXML;
 var n = xmlResponse.getElementsByTagName(id)[0].firstChild.nodeValue;
 return n;
}
function xml_to_val(xml, val){
 xmlResponse=xmlHttp.responseXML;
 document.getElementById(val).value = xmlResponse.getElementsByTagName(xml)[0].firstChild.nodeValue;
}
function send_request(submit,server){
 request = new XMLHttpRequest();
 request.open("GET", server, true);
 request.send();
 save_status(submit,request);
}
function save_status(submit,request){
 old_submit = submit.value;
 request.onreadystatechange = function() {
  if (request.readyState != 4) return;
  submit.value = request.responseText;
  setTimeout(function(){submit.value=old_submit}, 1000);
 }
 submit.value = 'Подождите...';
}